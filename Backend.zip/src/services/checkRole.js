export const checkRole = (req, res) => {
    return 'success'
}